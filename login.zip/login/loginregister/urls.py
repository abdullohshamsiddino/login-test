from django.urls import path
from loginregister.views import home_login, home_signup

urlpatterns = [
    path('login_home/', home_login),
    path('signup_home/', home_signup)
]